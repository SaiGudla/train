package money;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import database.Db;

@WebServlet("/getTrains")
public class TrainsServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Gson gson = null;
	Db db = null;

	public TrainsServlet() {
		db = new Db();
		gson = new Gson();
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		String FromSt = req.getParameter("from");
		String ToSt = req.getParameter("to");
		System.out.println(req.getParameter("from"));
		res.setContentType("application/json");
		String s = gson.toJson(db.getTrains(FromSt, ToSt));
		System.out.println(db.Trains);
		try {
			res.getWriter().write(s);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
